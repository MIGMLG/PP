/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Expenses;

import static Expenses.CurrencyRates.*;
import java.util.Date;

/**
 *
 * @author NERD-X
 */
public class Expenses {

    private static final int NUMBER_OF_DAYS = 31;

    protected String type;

    protected int number;
    protected float value;
    protected Date data;

    public Expenses(int number, float value, Date data) {
        this.type = "outro";
        this.number = number;
        this.value = value;
        this.data = data;
    }

    public Expenses(String type, int number, float value, Date data) {
        this.type = type;
        this.number = number;
        this.value = value;
        this.data = data;
    }

    public Expenses(int number, float value, Date data, String currencyType) {
        if ("EURO".equals(currencyType.toUpperCase())) {
            this.type = "outro";
            this.number = number;
            this.value = value;
            this.data = data;
        } else {
            this.type = "outro";
            this.number = number;
            this.data = data;
            if ("DOLAR".equals(currencyType.toUpperCase())) {
                this.value = getFromDolar(value);
            } else if ("IENE".equals(currencyType.toUpperCase())) {
                this.value = getFromIene(value);
            }
        }
    }

    public Expenses(String type, int number, float value, Date data, String currencyType) {
        if ("EURO".equals(currencyType.toUpperCase())) {
            this.type = type;
            this.number = number;
            this.value = value;
            this.data = data;
        } else {
            this.type = type;
            this.number = number;
            this.data = data;
            if ("DOLAR".equals(currencyType.toUpperCase())) {
                this.value = getFromDolar(value);
            } else if ("IENE".equals(currencyType.toUpperCase())) {
                this.value = getFromIene(value);
            }
        }
    }

    @Override
    public String toString() {
        String despesa = "\n"
                + "Type : " + type + "\n"
                + "Number : " + number + "\n"
                + "Value : " + value + "\n"
                + "Data : " + data ;
        return despesa;
    }

}

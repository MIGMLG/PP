/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Expenses;

import java.util.Date;

/**
 *
 * @author NERD-X
 */
public class User {

    private final int ID_SIZE = 3;
    protected char[] id = new char[ID_SIZE];
    protected String name;
    protected Date data;
    protected String email;
    protected Expenses[] expenses;
    protected Subcription donations = new Subcription();

    public void makeDonations(double donation) {
        donations.setDonations(donation);
        //System.out.println("" + donations.isSubcriber());
    }

    public User(char[] id, String name, Date data, String email) {
        this.id = id;
        this.name = name;
        this.data = data;
        this.email = email;
    }

    public User(char[] id, String name, Date data, String email, Expenses[] despesas) {
        this.id = id;
        this.name = name;
        this.data = data;
        this.email = email;
        this.expenses = despesas;
    }

    @Override
    public String toString() {
        int i = 0;
        int Total = 0;
        String despesas = "";

        while (i < expenses.length && expenses[i] != null) {
            Total += 1;
            despesas += expenses[i].toString() + "\n";
            i++;
        }

        String user = "ID : " + new String(id) + "\n"
                + "Nome : " + name + "\n"
                + "Data : " + data + "\n"
                + "Email : " + email + "\n"
                + "Depesas : " + "\n" + despesas + "\n"
                + "Utilizador : " + donations.toString();
        return user;
    }

    public String mostExpensiveByMonth(int year) {
        String info = "";
        if (donations.isSubcriber() == false) {
            info = "Only Available for Subs.";
        } else {
            info = PremiumFeatures.mostExpensiveByMonth(expenses, year);
        }
        return info;
    }

    public String totalByMonth(int year) {
        String info = "";
        if (donations.isSubcriber() == false) {
            info = "Only Available for Subs.";
        } else {
            info = PremiumFeatures.totalCostByMonth(expenses, year);
        }
        return info;
    }

    public String mostExpensiveByPeriod(Date beginDate, Date endDate) {
        String info = "";
        if (donations.isSubcriber() == false) {
            info = "Only Available for Subs.";
        } else {
            info = PremiumFeatures.mostExpensiveByPeriod(expenses, beginDate, endDate);
        }
        return info;
    }

}

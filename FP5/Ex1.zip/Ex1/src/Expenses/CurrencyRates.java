/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Expenses;

/**
 *
 * @author NERD-X
 */
public class CurrencyRates {
   protected static float fromDolar = (float) 0.769;
   protected static float fromIene = 125;
   protected static float fromGBP = (float) 0.87;

    public static float getFromDolar(float money) {
        return (money * fromDolar);
    }

    public static float getFromIene(float money) {
        return (money * fromIene);
    }

//    public static double getToGBP(double money) {
//        return (money *toGBP);
//    }
     
}
